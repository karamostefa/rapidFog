'use strict';
/*
 * RapidFog prototype (v2): draft specification, challenge ablation, proposed protocol, attacks and benchmarks.
 *   node rapidfog.js > results.txt
 * Modular exponentiation of 2048-bit numbers is executed natively by OpenSSL through Node's DH API
 * (base^exp mod p); all other logic uses BigInt. MAC and PRF are HMAC-SHA256 (PRF in counter mode).
 * v2 changes: the algebraic challenge A_i = w^-1 c1 + h c2 mod p is replaced by a sealed challenge
 * (pad + MAC under w_i), H_G hashes to a full-length value before squaring, and FV checks forward with the
 * short sums S1, S2 instead of their full-size inverses. The v1 code is kept in _obsolete/.
 */
const crypto = require('crypto');
const { performance } = require('perf_hooks');

// ---------------------------------------------------------------- numeric helpers
const hex2big = (h) => BigInt('0x' + (h || '0'));
const big2buf = (x, len) => { let h = x.toString(16); if (h.length % 2) h = '0' + h; const b = Buffer.from(h, 'hex'); return len ? Buffer.concat([Buffer.alloc(Math.max(0, len - b.length)), b]) : b; };
const rndBits = (bits) => { const b = crypto.randomBytes(Math.ceil(bits / 8)); return hex2big(b.toString('hex')) & ((1n << BigInt(bits)) - 1n); };
const rndRange = (lo, hi) => lo + (rndBits(hi.toString(2).length + 64) % (hi - lo));        // [lo, hi)
const rnd256 = () => (1n << 255n) | rndBits(255);
const bitlen = (x) => x.toString(2).length;
function egcd(a, b) { let x0 = 1n, x1 = 0n; while (b) { const q = a / b;[a, b] = [b, a % b];[x0, x1] = [x1, x0 - q * x1]; } return [a, x0]; }
const modinv = (a, m) => { const [g, x] = egcd(((a % m) + m) % m, m); if (g !== 1n) throw new Error('no inverse'); return ((x % m) + m) % m; };
const gcd = (a, b) => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) [a, b] = [b, a % b]; return a; };
const mod = (a, m) => ((a % m) + m) % m;

// 2048-bit safe prime p = 2q+1 generated with OpenSSL (genprime.js). A freshly generated prime is not a "named group",
// so OpenSSL does not impose its subgroup membership test on bases, which our arbitrary-base exponentiations need.
let primeHex = require('fs').readFileSync(__dirname + '/safeprime.txt', 'utf8').trim(); if (primeHex.length % 2) primeHex = '0' + primeHex;
const P = hex2big(primeHex), Q = (P - 1n) / 2n, PM1 = P - 1n, PLEN = 256;
const dh = crypto.createDiffieHellman(Buffer.from(primeHex, 'hex'), Buffer.from([2]));
function mpow(base, exp) {                                           // base^exp mod P (native)
  base = mod(base, P); if (base <= 1n || base === P - 1n) return mpowBig(base, exp, P);   // OpenSSL rejects these bases
  dh.setPrivateKey(big2buf(exp));
  const r = dh.computeSecret(big2buf(base, PLEN));
  return r.length ? hex2big(r.toString('hex')) : 1n;                // OpenSSL returns an empty secret when the result is 1
}
function mpowBig(b, e, m) { let r = 1n; b %= m; while (e > 0n) { if (e & 1n) r = (r * b) % m; e >>= 1n; b = (b * b) % m; } return r; }
{ const b = rndBits(2000) | 2n, e = rndBits(300) | 1n; if (mpow(b, e) !== mpowBig(b, e, P)) throw new Error('native modexp mismatch'); }

// ---------------------------------------------------------------- hashing, MAC, PRF
// G: plain SHA-256 of a labelled, '|'-separated encoding (numbers never contain '|'), used as the random oracle H.
const G = (label, ...parts) => hex2big(crypto.createHash('sha256').update(label + '|' + parts.map(String).join('|')).digest('hex'));
const keyBuf = (k) => (Array.isArray(k) ? Buffer.concat(k.map((x) => big2buf(x, 32))) : big2buf(k, 32));
// MAC_k(label, parts) = HMAC-SHA256 ; PRF_k(label, parts, bits) = HMAC-SHA256 in counter mode, truncated
const mac = (k, label, ...parts) => hex2big(crypto.createHmac('sha256', keyBuf(k)).update(label + '|' + parts.map(String).join('|')).digest('hex'));
function prf(k, label, parts, bits) { let out = 0n, got = 0, i = 0; while (got < bits) { out = (out << 256n) | mac(k, label + '#' + i, ...parts); got += 256; i++; } return out >> BigInt(got - bits); }
// Draft-design pads (plain hash, as in v1) are kept for the ablation only.
function hpad(label, parts, bits) { let out = 0n, got = 0, i = 0; while (got < bits) { out = (out << 256n) | G(label + '#' + i, ...parts); got += 256; i++; } return out >> BigInt(got - bits); }
// Hash into G: expand to |p|+128 bits (statistically close to uniform mod p), reduce, square -> quadratic residue.
const HG = (M) => { const u = hpad('HG', [M], 2048 + 128) % P; return (u * u) % P; };
const HGv1 = (M) => { const h = G('H', M) % P; return (h * h) % P; };       // v1 instantiation (for the range check only)

function bench(fn, iters, reps = 5) {
  for (let i = 0; i < Math.min(iters, 5); i++) fn(i);
  const r = []; for (let k = 0; k < reps; k++) { const t0 = process.hrtime.bigint(); for (let i = 0; i < iters; i++) fn(i); r.push(Number(process.hrtime.bigint() - t0) / 1000 / iters); }
  r.sort((a, b) => a - b); return r[Math.floor(reps / 2)];
}
const f = (x, d = 2) => x.toFixed(d);
const log = (...a) => console.log(...a);
const OUT = {};

log('=== environment ===\nnode', process.version, process.platform, process.arch, '| p = 2048-bit safe prime (generated), bits =', bitlen(P));
OUT.tShort = bench(() => mpow(rndBits(2000) | 2n, rnd256()), 100); OUT.tFull = bench(() => mpow(rndBits(2000) | 2n, rndBits(2046) | 1n), 40);
log('mpow timings: 256-bit exp', f(OUT.tShort, 1), 'us ; 2048-bit exp', f(OUT.tFull, 1), 'us');

// ================================================================ A. DRAFT SPECIFICATION (algebraic masks, as in the first draft)
function naiveInit(n, weak = false) {
  const nodes = [];
  for (let i = 0; i < n; i++) {
    let w, h;
    if (weak) { const pw = 'pw' + Math.floor(Math.random() * 65536); w = hex2big(Buffer.from(pw).toString('hex')); h = G('h', pw); nodes.push({ pw }); nodes[i].w = w; nodes[i].h = h; }
    else { w = rnd256(); h = G('h', w); nodes.push({ w, h }); }
    const nd = nodes[i]; nd.id = 'N' + i;
    nd.c1 = rndRange(1n << 128n, nd.h); nd.c2 = rnd256();
  }
  const sum = (k) => nodes.reduce((a, x) => a + x[k], 0n);
  if (sum('c1') % 2n === 0n) nodes[0].c1 += 1n;
  if (sum('c2') % 2n === 0n) nodes[0].c2 += 1n;
  for (const nd of nodes) nd.A = mod(modinv(nd.w, P) * nd.c1 + nd.h * nd.c2, P);
  let s = rnd256() | 1n;
  return { nodes, s, S1: sum('c1'), S2: sum('c2') };
}
function naiveChg(nd) {
  const X = mod(nd.A * nd.w, P); const c1 = X % nd.h, c2 = (X - c1) / (nd.w * nd.h);
  const A1 = G('A1', nd.id, c1, c2); const c1p = rnd256(), c2p = rnd256();
  return { c1, c2, A1, x: c1 + c1p + nd.w, y: c2 + c2p + nd.h, c1p, c2p };
}
function naiveTTPauthN(st, nd, msg) {
  if (G('A1', nd.id, nd.c1, nd.c2) !== msg.A1) return null;
  const c1p = msg.x - nd.c1 - nd.w, c2p = msg.y - nd.c2 - nd.h;
  return { A2: G('A2', c1p, c2p, nd.id), S: mod(st.s * c1p * c2p, P), hs: G('hs', st.s) };
}
{
  log('\n=== A. attacks on the draft specification (algebraic masks) ===');
  let hit = 0; const T = 200;
  for (let t = 0; t < T; t++) {
    const st = naiveInit(4); const Ss = [];
    for (const nd of st.nodes) { const m = naiveChg(nd); Ss.push(naiveTTPauthN(st, nd, m).S); }
    let g = Ss[0]; for (const S of Ss.slice(1)) g = gcd(g, S);
    for (let d = 1n; d < 100000n; d++) if (g % d === 0n) { const cand = g / d; if (cand === st.s) { hit++; break; } }
  }
  log(`A1 passive GCD attack on S_i (4 observed handshakes): s recovered in ${hit}/${T} trials`); OUT.gcd = [hit, T];

  let hit2 = 0; const T2 = 50;
  for (let t = 0; t < T2; t++) {
    const st = naiveInit(3), nd = st.nodes[0]; const m0 = naiveChg(nd);
    const rows = [], rhs = [];
    for (let j = 0; j < 4; j++) { const x = rndBits(300), y = rndBits(300); const r = naiveTTPauthN(st, nd, { A1: m0.A1, x, y }); rows.push([mod(x * y, P), mod(-x, P), mod(-y, P), 1n]); rhs.push(r.S); }
    const M = rows.map((r, i) => [...r, rhs[i]]);
    for (let c = 0; c < 4; c++) { let piv = c; while (M[piv][c] === 0n) piv++;[M[c], M[piv]] = [M[piv], M[c]]; const iv = modinv(M[c][c], P); M[c] = M[c].map((v) => (v * iv) % P); for (let r = 0; r < 4; r++) if (r !== c) { const k = M[r][c]; M[r] = M[r].map((v, j) => mod(v - k * M[c][j], P)); } }
    if (M[0][4] === st.s) hit2++;
  }
  log(`A2 active replay of A' + 4 chosen (x,y): s recovered in ${hit2}/${T2} trials`); OUT.oracle = [hit2, T2];

  let hit3 = 0; const T3 = 5; let tms = 0;
  for (let t = 0; t < T3; t++) {
    const st = naiveInit(1, true), nd = st.nodes[0], m = naiveChg(nd);
    const t0 = performance.now(); let found = null;
    for (let k = 0; k < 65536 && !found; k++) {
      const pw = 'pw' + k, w = hex2big(Buffer.from(pw).toString('hex')), h = G('h', pw);
      const X = mod(nd.A * w, P), c1 = X % h, c2 = (X - c1) / (w * h);
      if (G('A1', nd.id, c1, c2) === m.A1) found = pw;
    }
    tms += performance.now() - t0; if (found === nd.pw) hit3++;
  }
  log(`A3 offline dictionary attack (2^16 passwords) on A_i with observed A': password found in ${hit3}/${T3}, ${f(tms / T3, 0)} ms each`); OUT.dict = [hit3, T3, tms / T3];

  const st = naiveInit(3); const m = rndBits(1500) | 2n; let a = 1n, b = 1n; const hm = G('H', m) % P;
  for (const nd of st.nodes) { a = (a * mpow(m, nd.c1)) % P; b = (b * mpow(hm, nd.c2)) % P; }
  const e = mpow(m, st.s);
  const fvNaive = (a, b, e) => { const si = modinv(st.s, PM1); const mh = mpow(e, si), m1 = mpow(a, modinv(st.S1, PM1)), h1 = mpow(b, modinv(st.S2, PM1)); return mh === m1 && (G('H', m1) % P) === h1; };
  const ok1 = fvNaive(a, b, e), ok2 = fvNaive(a, b, e);
  log(`A4 draft FV: correct tuple accepted=${ok1}; same tuple replayed later accepted=${ok2}`); OUT.replay = [ok1, ok2];
  const nd = st.nodes[0], mm = naiveChg(nd), r = naiveTTPauthN(st, nd, mm);
  const c1p = mm.x - mm.c1 - nd.w, c2p = mm.y - mm.c2 - nd.h; const sRec = mod(r.S * modinv(mod(c1p * c2p, P), P), P);
  log(`A6 later compromise of w_i recovers recorded session secret s: ${sRec === st.s}`); OUT.fs = sRec === st.s;
}

// ================================================================ PROTOCOL (Phase II identical for both challenge modes)
// mode 'sealed'   : A_i = (N0, C_i, tau_i), C_i = (c1||c2) xor PRF_w('chg', id, epoch, N0), tau_i = MAC_w('chg', id, epoch, N0, C_i)
// mode 'algebraic': A_i = w^-1 c1 + h c2 mod p with h = H(w), c1 < h  (challenge of the first draft and of v1)
function ttpInit(n, mode = 'sealed', epoch = 1n, blind = 0) {      // TTP_init (blind > 0: the first node gets (256+blind)-bit shares)
  const mk = (id) => { const w = rnd256(), L = id === 'N0' ? 256 + blind : 256; const e = { id, w, lastEpoch: 0n }; if (mode === 'algebraic') { e.h = G('h', w); e.c1 = rndRange(1n << 128n, e.h); } else e.c1 = rndBits(L) || 1n; e.c2 = rndBits(L) || 1n; return e; };
  const nodes = []; for (let i = 0; i < n; i++) nodes.push(mk('N' + i));
  const fog = mk('F');
  const t = rnd256() | 1n;                                         // short verification exponent, s = t^{-1} mod p-1
  const st = { mode, nodes, fog, t, s: modinv(t, PM1), S1: nodes.reduce((a, x) => a + x.c1, 0n), S2: nodes.reduce((a, x) => a + x.c2, 0n), epoch, seen: new Set() };
  for (const e of [...nodes, fog]) e.A = makeChallenge(st, e);
  return st;
}
function makeChallenge(st, e) {
  if (st.mode === 'algebraic') return { A: mod(modinv(e.w, P) * e.c1 + e.h * e.c2, P), N0: 0n, epoch: st.epoch };
  const N0 = rndBits(128), C = ((e.c1 << 256n) | e.c2) ^ prf(e.w, 'chg', [e.id, st.epoch, N0], 512);
  return { N0, C, epoch: st.epoch, tau: mac(e.w, 'chg', e.id, st.epoch, N0, C) };
}
function openChallenge(ent, ch, w = ent.w) {                      // entity side: authenticate and open the challenge
  if (ch.N0 === 0n) { const h = G('h', w); const X = mod(ch.A * w, P); const c1 = X % h; return [c1, (X - c1) / (w * h)]; }
  if (ch.epoch <= ent.lastEpoch || mac(w, 'chg', ent.id, ch.epoch, ch.N0, ch.C) !== ch.tau) return null;
  if (w === ent.w) ent.lastEpoch = ch.epoch;                         // an epoch is accepted once, so a replayed challenge is rejected
  const v = ch.C ^ prf(w, 'chg', [ent.id, ch.epoch, ch.N0], 512); return [v >> 256n, v & ((1n << 256n) - 1n)];
}
function chg(ent) {                                                // Chg (node or fog node)
  const r = openChallenge(ent, ent.A); if (!r) return null; const [c1, c2] = r;
  const N = rndBits(128), c1p = rnd256(), c2p = rnd256();
  const xy = ((c1p << 256n) | c2p) ^ prf(ent.w, 'xy', [ent.id, ent.A.N0, N], 512);
  const A1 = mac(ent.w, 'req', ent.id, ent.A.N0, N, xy, c1, c2);
  ent.tmp = { c1, c2, c1p, c2p, N, epoch: ent.A.epoch };
  return { id: ent.id, N0: ent.A.N0, N, xy, A1 };
}
function ttpAuth(st, ent, msg, isFog) {                            // TTP_auth_N / TTP_auth_F
  if (st.seen.has(msg.N) || st.seen.has('N0:' + ent.id + ':' + ent.A.N0)) return null;          // one answered request per challenge
  if (mac(ent.w, 'req', ent.id, ent.A.N0, msg.N, msg.xy, ent.c1, ent.c2) !== msg.A1) return null;
  st.seen.add(msg.N); st.seen.add('N0:' + ent.id + ':' + ent.A.N0);
  const v = msg.xy ^ prf(ent.w, 'xy', [ent.id, ent.A.N0, msg.N], 512), K = [v >> 256n, v & ((1n << 256n) - 1n)];
  const St = st.t ^ prf(K, 't', [ent.id, msg.N], 256);
  if (!isFog) return { N: msg.N, St, A2: mac(K, 'resp', ent.id, msg.N, st.epoch, St) };
  const SS1 = st.S1 ^ prf(K, 'S1', [ent.id, msg.N], 272), SS2 = st.S2 ^ prf(K, 'S2', [ent.id, msg.N], 272);
  return { N: msg.N, St, SS1, SS2, A2: mac(K, 'respF', ent.id, msg.N, st.epoch, St, SS1, SS2) };
}
function entAuth(ent, resp, isFog) {                               // N_auth_TTP / F_auth_TTP
  const { c1, c2, c1p, c2p, N, epoch } = ent.tmp, K = [c1p, c2p];
  const tag = isFog ? mac(K, 'respF', ent.id, N, epoch, resp.St, resp.SS1, resp.SS2) : mac(K, 'resp', ent.id, N, epoch, resp.St);
  if (resp.N !== N || resp.A2 !== tag) return false;
  const t = resp.St ^ prf(K, 't', [ent.id, N], 256);
  if (!isFog) { ent.sess = { c1, c2, t, s: modinv(t, PM1), epoch, lastCtr: -1n }; return true; }
  ent.sess = { t, S1: resp.SS1 ^ prf(K, 'S1', [ent.id, N], 272), S2: resp.SS2 ^ prf(K, 'S2', [ent.id, N], 272), epoch, last: -1n }; return true;
}
const encodeMsg = (epoch, ctr, payload) => ((((1n << 8n) | (epoch & 0xffn)) << 64n | ctr) << 128n | rndBits(128)) << 1024n | payload; // < p
const decodeMsg = (M) => { const payload = M & ((1n << 1024n) - 1n); const r = M >> 1024n; const ctr = (r >> 128n) & ((1n << 64n) - 1n); const epoch = (r >> 192n) & 0xffn; return { epoch, ctr, payload }; };
function encSig(nd, M) { return { a: mpow(M, nd.sess.c1), b: mpow(HG(M), nd.sess.c2), e: mpow(M, nd.sess.s) }; }        // Enc_Sig
const WIN = 1n << 20n;                                             // counter window: a counter may advance by at most WIN per report
function aggSig(nd, tup) {                                         // AS: contributes only to a current, fresh, in-window counter
  if (!tup) return null;
  const Mh = mpow(tup.e, nd.sess.t), d = decodeMsg(Mh), s = nd.sess;
  if (d.epoch !== s.epoch % 256n || d.ctr <= s.lastCtr || d.ctr > s.lastCtr + WIN) return null;
  s.lastCtr = d.ctr;
  return { a: (tup.a * mpow(Mh, s.c1)) % P, b: (tup.b * mpow(HG(Mh), s.c2)) % P, e: tup.e };
}
function fv(fog, tup) {                                            // FV (forward check with the short sums)
  const s = fog.sess; if (!tup || [tup.a, tup.b, tup.e].some((v) => typeof v !== 'bigint' || v <= 1n || v >= P - 1n)) return { ok: false, why: 'range' };
  const Mh = mpow(tup.e, s.t);
  if (mpow(Mh, s.S1) !== tup.a || mpow(HG(Mh), s.S2) !== tup.b) return { ok: false, why: 'tuple' };
  const d = decodeMsg(Mh);
  if (d.epoch !== s.epoch % 256n) return { ok: false, why: 'epoch' };
  if (d.ctr <= s.last) return { ok: false, why: 'replay' };
  if (d.ctr > s.last + WIN) return { ok: false, why: 'window' };
  s.last = d.ctr; return { ok: true, payload: d.payload, M: Mh };
}
function fvInverse(fog, tup) {                                     // v1 order, for timing and equivalence check only
  const s = fog.sess; s.S1inv ??= modinv(s.S1, PM1); s.S2inv ??= modinv(s.S2, PM1);
  const Mh = mpow(tup.e, s.t), M1 = mpow(tup.a, s.S1inv), h1 = mpow(tup.b, s.S2inv); return Mh === M1 && HG(M1) === h1;
}
function setupSession(n, mode = 'sealed') {
  let st; do { st = ttpInit(n, mode); } while (gcd(st.S1, PM1) !== 1n || gcd(st.S2, PM1) !== 1n);   // only needed for fvInverse
  const tx = {};
  for (const nd of st.nodes) { const m = chg(nd); const r = m && ttpAuth(st, nd, m, false); if (!r || !entAuth(nd, r, false)) throw new Error('node auth failed'); }
  const mf = chg(st.fog); const rf = mf && ttpAuth(st, st.fog, mf, true); if (!rf || !entAuth(st.fog, rf, true)) throw new Error('fog auth failed');
  st.tx = { fogChallenge: st.fog.A, fogReq: mf, fogResp: rf };       // what an eavesdropper sees on the fog's link
  return st;
}
function signAggregate(st, ctr, payload, upto = st.nodes.length) {
  const M = encodeMsg(st.epoch, ctr, payload); let tup = encSig(st.nodes[0], M);
  for (let i = 1; i < upto; i++) tup = aggSig(st.nodes[i], tup);
  return { tup, M };
}

// ================================================================ B. CHALLENGE ABLATION: algebraic vs sealed (same Phase II)
function ratRecon(A) {            // half-extended Euclid on (P, A): r_i = s_i * A (mod P); stop when r_i < 2^800
  let r0 = P, r1 = A, s0 = 0n, s1 = 1n; const N = 1n << 800n;
  while (r1 >= N) { const q = r0 / r1;[r0, r1] = [r1, r0 - q * r1];[s0, s1] = [s1, s0 - q * s1]; }
  return { X: r1, w: s1 < 0n ? -s1 : s1 };
}
function attackChallenge(ent, ch) { // returns the candidate key w if it is confirmed by the public challenge, else null
  const A = ch.N0 === 0n ? ch.A : ch.C % P; const { X, w } = ratRecon(A);
  for (let g = 1n; g <= 4096n; g++) {
    const W = w * g, Xg = X * g; if (bitlen(W) > 256) break;
    if (ch.N0 === 0n) { const h = G('h', W), c1 = Xg % h; if ((Xg - c1) % (W * h) === 0n && mod(modinv(W, P) * c1 + h * ((Xg - c1) / (W * h)), P) === ch.A) return W; }
    else if (mac(W, 'chg', ent.id, ch.epoch, ch.N0, ch.C) === ch.tau) return W;
  }
  return null;
}
function passiveForgery(st) {       // outsider: sees the fog's challenge and Phase-II messages, corrupts no entity
  const { fogChallenge: ch, fogReq: rq, fogResp: rs } = st.tx, idf = st.fog.id;
  const w = attackChallenge(st.fog, ch); if (w === null) return false;
  const v = rq.xy ^ prf(w, 'xy', [idf, ch.N0, rq.N], 512), K = [v >> 256n, v & ((1n << 256n) - 1n)];
  const t = rs.St ^ prf(K, 't', [idf, rq.N], 256), S1 = rs.SS1 ^ prf(K, 'S1', [idf, rq.N], 272), S2 = rs.SS2 ^ prf(K, 'S2', [idf, rq.N], 272);
  const M = encodeMsg(st.epoch, 5n, 0xBADn), s = modinv(t, PM1);
  return fv(st.fog, { a: mpow(M, S1), b: mpow(HG(M), S2), e: mpow(M, s) }).ok;
}
{
  log('\n=== B. challenge ablation: algebraic challenge vs sealed challenge (same Phase II) ===');
  for (const mode of ['algebraic', 'sealed']) {
    let ok = 0; const T = mode === 'algebraic' ? 1000 : 100; const t0 = process.hrtime.bigint();
    for (let k = 0; k < T; k++) { const st = ttpInit(1, mode); const nd = st.nodes[0]; if (attackChallenge(nd, nd.A) === nd.w) ok++; }
    const us = Number(process.hrtime.bigint() - t0) / 1000 / T;
    let forged = 0; const T2 = 20; for (let k = 0; k < T2; k++) if (passiveForgery(setupSession(3, mode))) forged++;
    log(`${mode.padEnd(9)}: w_i recovered from ONE challenge in ${ok}/${T} trials (~${f(us, 0)} us each); passive outsider forgery accepted by FV in ${forged}/${T2}`);
    OUT['chal_' + mode] = { recovered: [ok, T], forged: [forged, T2] };
  }
}

// ================================================================ C. PROPOSED PROTOCOL: correctness and attack resistance
{
  log('\n=== C. proposed protocol (sealed challenge, MAC-based Phase II, forward FV) ===');
  for (const n of [1, 2, 5, 20, 100]) {
    const st = setupSession(n); const { tup } = signAggregate(st, 1n, rndBits(900));
    const r1 = fv(st.fog, tup), r2 = fv(st.fog, tup);
    const st2 = setupSession(n); const { tup: t2 } = signAggregate(st2, 1n, rndBits(900));
    const okA = fv(st2.fog, { ...t2, a: (t2.a * 2n) % P }).ok, okB = fv(st2.fog, { ...t2, b: (t2.b * 3n) % P }).ok;
    log(`n=${n}: accepted=${r1.ok}  replay -> ${r2.ok ? 'ACCEPTED' : 'rejected (' + r2.why + ')'}  modified a -> ${okA}  modified b -> ${okB}`);
  }
  { const st = setupSession(10); const { tup } = signAggregate(st, 7n, rndBits(900), 9); log('tuple with 9 of 10 contributions accepted =', fv(st.fog, tup).ok); }
  // n-1 colluders (all nodes except N_0, who is honest) forge on a fresh message: they know t, s and their own shares
  { let acc = 0; for (let k = 0; k < 20; k++) { const st = setupSession(10); const M = encodeMsg(st.epoch, 9n, rndBits(900)); let a = 1n, b = 1n;
      for (const nd of st.nodes.slice(1)) { a = (a * mpow(M, nd.sess.c1)) % P; b = (b * mpow(HG(M), nd.sess.c2)) % P; }
      if (fv(st.fog, { a, b, e: mpow(M, st.nodes[1].sess.s) }).ok) acc++; }
    log(`9 colluding nodes (honest N_0 absent) forge a tuple: accepted ${acc}/20`); OUT.collude = acc; }
  // malleability of (a, e): derived tuple for M^y is consistent in its first two checks, rejected by b
  { const st = setupSession(3); const { tup, M } = signAggregate(st, 3n, rndBits(900)); const y = rndBits(64) | 1n;
    const My = mpow(M, y), a2 = mpow(tup.a, y), e2 = mpow(tup.e, y), consistent = mpow(e2, st.fog.sess.t) === My && mpow(My, st.fog.sess.S1) === a2;
    log(`malleability: (a^y, e^y) consistent for M^y = ${consistent}; accepted by FV = ${fv(st.fog, { a: a2, b: tup.b, e: e2 }).ok}`); OUT.malleable = consistent; }
  // forward and inverse verification agree on valid and on modified tuples
  { let agree = 0; for (let k = 0; k < 50; k++) { const st = setupSession(4); const { tup } = signAggregate(st, 1n, rndBits(900)); const bad = k % 2 ? { ...tup, b: (tup.b * 5n) % P } : tup;
      const fwd = fv(st.fog, bad).ok; st.fog.sess.last = -1n; if (fwd === fvInverse(st.fog, bad)) agree++; }
    log(`forward FV and inverse FV agree on ${agree}/50 tuples (25 valid, 25 modified)`); OUT.agree = agree; }
  // handshake: GCD of delivered values, replayed or modified request, replayed or forged challenge
  { let hit = 0; for (let k = 0; k < 100; k++) { const st = ttpInit(4); const Ss = []; for (const nd of st.nodes) { const r = ttpAuth(st, nd, chg(nd), false); if (!r) throw new Error('auth'); Ss.push(r.St); } let g = Ss[0]; for (const S of Ss.slice(1)) g = gcd(g, S); if (g === st.t) hit++; }
    log(`GCD attack on delivered values recovers t in ${hit}/100`); OUT.gcdH = hit; }
  { let acc = 0; for (let k = 0; k < 100; k++) { const st = ttpInit(2), nd = st.nodes[0], m = chg(nd); const r1 = ttpAuth(st, nd, m, false); if (!r1) throw new Error('auth'); const r2 = ttpAuth(st, nd, { ...m, xy: rndBits(512), N: rndBits(128) }, false); const r3 = ttpAuth(st, nd, m, false); if (r2 || r3) acc++; }
    log(`replayed or modified request answered by the TTP in ${acc}/100`); OUT.reqH = acc; }
  { let acc = 0; for (let k = 0; k < 100; k++) { const st = setupSession(2), nd = st.nodes[0]; const old = nd.A;   // node already accepted epoch 1
      const forged = { ...makeChallenge({ ...st, epoch: 2n }, nd), C: rndBits(512) };
      if (openChallenge(nd, old) || openChallenge(nd, forged)) acc++; if (!openChallenge(nd, makeChallenge({ ...st, epoch: 2n }, nd))) throw new Error('genuine challenge rejected'); }
    log(`replayed (old epoch) or modified challenge accepted by the node in ${acc}/100 (genuine next-epoch challenge accepted 100/100)`); OUT.chalH = acc; }
  // replay while the handshake is still open: the node accepts an epoch once, the TTP answers one request per challenge
  { let accN = 0, accT = 0; for (let k = 0; k < 100; k++) { const st = ttpInit(2), nd = st.nodes[0], m = chg(nd); if (!m) throw new Error('chg');
      if (openChallenge(nd, nd.A)) accN++; nd.lastEpoch = 0n; const m2 = chg(nd); if (!ttpAuth(st, nd, m, false)) throw new Error('auth'); if (m2 && ttpAuth(st, nd, m2, false)) accT++; }
    log(`challenge replayed during the handshake accepted by the node in ${accN}/100; second request for the same challenge answered by the TTP in ${accT}/100`); OUT.chalOpen = [accN, accT]; }
  // a password-derived key falls to an offline dictionary attack on the sealed challenge (the MAC tests every guess)
  { let hit = 0; const T3 = 3; let tms = 0; for (let k = 0; k < T3; k++) {
      const pw = 'pw' + Math.floor(Math.random() * 65536), st = ttpInit(1), nd = st.nodes[0]; nd.w = hex2big(Buffer.from(pw).toString('hex')); nd.A = makeChallenge(st, nd);
      const t0 = performance.now(); let found = null;
      for (let g = 0; g < 65536 && !found; g++) { const w = hex2big(Buffer.from('pw' + g).toString('hex')); if (mac(w, 'chg', nd.id, nd.A.epoch, nd.A.N0, nd.A.C) === nd.A.tau) found = 'pw' + g; }
      tms += performance.now() - t0; if (found === pw) hit++; }
    log(`offline dictionary attack (2^16 passwords) on the sealed challenge with a password-derived key: found in ${hit}/${T3}, ${f(tms / T3, 0)} ms each`); OUT.dictSealed = [hit, T3, tms / T3]; }
  // a corrupted first node chooses the payload (participation, not endorsement); it cannot burn the counter space
  { let pay = 0, burn = 0, after = 0; for (let k = 0; k < 20; k++) { const st = setupSession(5);
      if (fv(st.fog, signAggregate(st, 1n, 0xBADn).tup).ok) pay++;
      if (!fv(st.fog, signAggregate(st, (1n << 64n) - 1n, rndBits(900)).tup).ok) burn++;
      if (fv(st.fog, signAggregate(st, 2n, rndBits(900)).tup).ok) after++; }
    log(`corrupted first node: own payload accepted ${pay}/20; counter jump to 2^64-1 refused ${burn}/20; next honest report accepted ${after}/20`); OUT.firstNode = [pay, burn, after]; }
  // the sums reveal the approximate cluster size unless the first node holds a longer blinding share
  { const est = (blind) => { let err = 0; const T = 100; for (let k = 0; k < T; k++) { const n = 5 + Math.floor(Math.random() * 196), st = ttpInit(n, 'sealed', 1n, blind); const nh = Number((st.S1 + st.S2) >> 255n) / 2; err += Math.abs(nh - n) / n; } return err / T; };
    const e0 = est(0), e64 = est(64);
    log(`cluster-size estimate (S1+S2)/2^256 for n in [5,200]: mean relative error ${f(100 * e0, 1)}% without blinding; with a 64-bit-longer blinding share at the first node the estimate is off by a factor of about 2^${f(Math.log2(e64), 0)}`); OUT.nEstimate = [e0, e64]; }
  { let fsHit = 0; for (let k = 0; k < 50; k++) { const st = setupSession(2), { fogChallenge: ch, fogReq: rq, fogResp: rs } = st.tx, w = st.fog.w;   // attacker later learns w_f
      const v = rq.xy ^ prf(w, 'xy', [st.fog.id, ch.N0, rq.N], 512); if ((rs.St ^ prf([v >> 256n, v & ((1n << 256n) - 1n)], 't', [st.fog.id, rq.N], 256)) === st.t) fsHit++; }
    log(`later compromise of w_f recovers the recorded session exponent t in ${fsHit}/50 (no forward secrecy without the DH extension)`); OUT.fsH = fsHit; }
  // range of H_G: v1 instantiation never wraps mod p; v2 output spans the whole group
  { let mx1 = 0, mn2 = 1e9, qr = 0; for (let k = 0; k < 1000; k++) { const M = rndBits(1400); mx1 = Math.max(mx1, bitlen(HGv1(M))); const h = HG(M); mn2 = Math.min(mn2, bitlen(h)); if (mpow(h, Q) === 1n) qr++; }
    log(`H_G range over 1000 messages: v1 max ${mx1} bits (never reduced mod p); v2 min ${mn2} bits, quadratic residues ${qr}/1000`); OUT.hg = { v1max: mx1, v2min: mn2, qr }; }
}

// ================================================================ D. BENCHMARKS
{
  log('\n=== D. cost of the nine functions (proposed profile, 2048-bit p, native modexp), median us ===');
  const n = 20; const st = ttpInit(n); const nd = st.nodes[0];
  const tInit = bench(() => ttpInit(100), 3) / 101;
  const tChg = bench(() => { nd.lastEpoch = 0n; return chg(nd); }, 300);
  nd.lastEpoch = 0n; const msg = chg(nd);
  const tTA = bench(() => { st.seen.clear(); return ttpAuth(st, nd, msg, false); }, 300);
  st.seen.clear(); const resp = ttpAuth(st, nd, msg, false);
  const tNA = bench(() => entAuth(nd, resp, false), 300);
  const mf = chg(st.fog); const tFA = bench(() => { st.seen.clear(); return ttpAuth(st, st.fog, mf, true); }, 300); st.seen.clear(); const rf = ttpAuth(st, st.fog, mf, true);
  const tFA2 = bench(() => entAuth(st.fog, rf, true), 300);
  const sess = setupSession(n); const M = encodeMsg(1n, 1n, rndBits(900));
  const tEnc = bench(() => encSig(sess.nodes[0], M), 100), t0 = encSig(sess.nodes[0], M);
  const tAS = bench(() => { sess.nodes[1].sess.lastCtr = -1n; return aggSig(sess.nodes[1], t0); }, 100);
  const sFog = setupSession(n); const { tup } = signAggregate(sFog, 1n, rndBits(900));
  const tFV = bench(() => { sFog.fog.sess.last = -1n; return fv(sFog.fog, tup); }, 200);
  const tFVinv = bench(() => fvInverse(sFog.fog, tup), 100);
  const tBonly = bench(() => { const Mh = mpow(tup.e, sFog.fog.sess.t); return mpow(HG(Mh), sFog.fog.sess.S2) === tup.b; }, 200);
  const tHG = bench(() => HG(M), 2000);
  log(`TTP_init per entity ${f(tInit)} | Chg ${f(tChg)} | TTP_auth_N ${f(tTA)} | N_auth_TTP ${f(tNA)} | TTP_auth_F ${f(tFA)} | F_auth_TTP ${f(tFA2)}`);
  log(`Enc_Sig (origin, full-size s) ${f(tEnc)} | AS per hop ${f(tAS)} | FV forward ${f(tFV)} | FV with inverses (v1 order) ${f(tFVinv)} | b-only check ${f(tBonly)} | H_G ${f(tHG)}   [tuple = 3 x ${PLEN} bytes]`);
  log(`bit lengths: t ${bitlen(sFog.fog.sess.t)} | S1 ${bitlen(sFog.fog.sess.S1)} | S2 ${bitlen(sFog.fog.sess.S2)} | S1^-1 ${bitlen(sFog.fog.sess.S1inv)} | S2^-1 ${bitlen(sFog.fog.sess.S2inv)}`);
  OUT.cost = { tInit, tChg, tTA, tNA, tFA, tFA2, tEnc, tAS, tFV, tFVinv, tBonly, tHG };

  log('\nFV vs number of nodes n (tuple verification time, us) and aggregation latency (n hops, ms):');
  OUT.scal = [];
  for (const nn of [5, 20, 50, 100, 200]) {
    const s2 = setupSession(nn); const { tup: tp } = signAggregate(s2, 1n, rndBits(900));
    const tv = bench(() => { s2.fog.sess.last = -1n; return fv(s2.fog, tp); }, 100);
    const t0s = performance.now(); signAggregate(s2, 2n, rndBits(900)); const lat = performance.now() - t0s;
    const tp0 = performance.now(); setupSession(nn); const prov = performance.now() - tp0;
    log(`n=${nn}: FV ${f(tv)} us   chain latency ${f(lat)} ms   provisioning (all handshakes, sequential) ${f(prov)} ms`); OUT.scal.push([nn, tv, lat, prov]);
  }
  const ec = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' }), ed = crypto.generateKeyPairSync('ed25519');
  const data = Buffer.from('cluster report'); const sigE = crypto.sign('sha256', data, ec.privateKey), sigD = crypto.sign(null, data, ed.privateKey);
  const tEc = bench(() => crypto.verify('sha256', data, ec.publicKey, sigE), 2000), tEd = bench(() => crypto.verify(null, data, ed.publicKey, sigD), 2000);
  const key = crypto.randomBytes(32), d64 = crypto.randomBytes(64), tag = crypto.createHmac('sha256', key).update(d64).digest();
  const tHm = bench(() => crypto.timingSafeEqual(crypto.createHmac('sha256', key).update(d64).digest(), tag), 20000);
  log(`baselines (one verification, Node): ECDSA-P256 ${f(tEc)} us | Ed25519 ${f(tEd)} us | HMAC-SHA256 incl. JS call overhead ${f(tHm)} us`);
  const nstarEc = tFV / tEc, nstarEd = tFV / tEd;
  log(`break-even cluster size n* (n x verify = FV): vs ECDSA ${f(nstarEc, 1)} | vs Ed25519 ${f(nstarEd, 1)}`);
  log(`FV throughput: ${f(1e6 / tFV, 0)} tuples/s (single thread). Tuple 768 B.`);
  OUT.base = { tEc, tEd, tHm, nstarEc, nstarEd };
}
require('fs').writeFileSync(__dirname + '/results.json', JSON.stringify(OUT, (k, v) => typeof v === 'bigint' ? String(v) : v, 1));
log('\nDONE');
