'use strict';
// Timing of the exponentiations that dominate RapidFog for different modulus sizes (primes need not be safe for timing).
const crypto = require('crypto');
const hex2big = (h) => BigInt('0x' + h);
const big2buf = (x, len) => { let h = x.toString(16); if (h.length % 2) h = '0' + h; const b = Buffer.from(h, 'hex'); return len ? Buffer.concat([Buffer.alloc(Math.max(0, len - b.length)), b]) : b; };
const rndBits = (bits) => { const b = crypto.randomBytes(Math.ceil(bits / 8)); return hex2big(b.toString('hex')) & ((1n << BigInt(bits)) - 1n); };
function bench(fn, iters, reps = 7) { for (let i = 0; i < 3; i++) fn(); const r = []; for (let k = 0; k < reps; k++) { const t0 = process.hrtime.bigint(); for (let i = 0; i < iters; i++) fn(); r.push(Number(process.hrtime.bigint() - t0) / 1000 / iters); } r.sort((a, b) => a - b); return r[Math.floor(reps / 2)]; }
const out = [];
for (const bits of [1024, 2048, 3072]) {
  const p = crypto.generatePrimeSync(bits, { bigint: true });
  let ph = p.toString(16); if (ph.length % 2) ph = '0' + ph;
  const dh = crypto.createDiffieHellman(Buffer.from(ph, 'hex'), Buffer.from([2])); const L = bits / 8;
  const mpow = (b, e) => { dh.setPrivateKey(big2buf(e)); return dh.computeSecret(big2buf(b, L)); };
  const base = (rndBits(bits - 8) | 2n), eShort = (1n << 255n) | rndBits(255), eFull = (1n << BigInt(bits - 2)) | rndBits(bits - 2);
  const tS = bench(() => mpow(base, eShort), bits === 3072 ? 60 : 150), tF = bench(() => mpow(base, eFull), bits === 3072 ? 20 : 40);
  // FV (forward check) = e^t, M^S1, H_G(M)^S2: three exponentiations with ~256-bit exponents; v1 used two full-size inverses
  const fv = 3 * tS, fvV1 = 2 * tF + tS, as = 3 * tS, enc = tF + 2 * tS;
  console.log(`p=${bits} bits: 256-bit exp ${tS.toFixed(0)} us, full exp ${tF.toFixed(0)} us | FV = 3 short = ${(fv / 1000).toFixed(2)} ms (v1: 2 full + 1 short = ${(fvV1 / 1000).toFixed(2)} ms) | AS hop ${(as / 1000).toFixed(2)} ms | Enc_Sig ${(enc / 1000).toFixed(2)} ms | tuple ${3 * L} B`);
  out.push({ bits, tS, tF, fv, fvV1, as, enc, tuple: 3 * L });
}
require('fs').writeFileSync(__dirname + '/results_mod.json', JSON.stringify(out, null, 1));
