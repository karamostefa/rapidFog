// Generates a 2048-bit safe prime p = 2q+1 (q prime) with OpenSSL and stores it in safeprime.txt
const crypto = require('crypto');
const t0 = Date.now();
crypto.generatePrime(2048, { safe: true, bigint: true }, (err, p) => {
  if (err) throw err;
  require('fs').writeFileSync(__dirname + '/safeprime.txt', p.toString(16));
  console.log('generated in', ((Date.now() - t0) / 1000).toFixed(1), 's');
});
