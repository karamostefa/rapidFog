#!/usr/bin/env bash
# Runs the ProVerif model of RapidFog's Phases I-II in four scenarios and writes results_proverif.txt.
#   PROVERIF=/path/to/proverif ./run.sh
set -e
cd "$(dirname "$0")"
PV="${PROVERIF:-proverif}"
OUT=results_proverif.txt; TMP=$(mktemp -d)
gen() { sed -e "s/CORRUPT_B/$1/" -e "s/PHASE_FS/$2/" -e "s/REPLAY/$3/" rapidfog_handshake.pv > "$TMP/$4.pv"; }
gen "0"            ""                           "" honest
gen "out(c, wB)"   ""                           "" corruptB
gen "0"            "| (phase 1; out(c, wF))"    "" forward_secrecy
gen "0"            ""                           "!" mutant_replay
{ echo "# $("$PV" -help 2>&1 | head -1)"; echo "# $(date -u +%Y-%m-%dT%H:%MZ)"
  for s in honest corruptB forward_secrecy mutant_replay; do
    echo; echo "=== scenario: $s"
    start=$(date +%s%N); "$PV" "$TMP/$s.pv" > "$TMP/$s.out" 2>&1; end=$(date +%s%N)
    grep -E "^RESULT|rror" "$TMP/$s.out" | sed 's/\[!1 = [^]]*\]//g; s/\[\]//g'
    echo "time: $(( (end - start) / 1000000 )) ms"
  done; } > "$OUT"
cat "$OUT"
