# iot_sim: RapidFog node cost on an emulated Cortex-M4 and chain simulation

1. `firmware/` : bare-metal C (mbed TLS 3.6.8 big numbers, SHA-256, ECDSA P-256 baseline). `python firmware/run_sim.py -O2`
   builds it with arm-none-eabi-gcc 15.2.1 (xPack) and runs it in Renode 1.17.0 (STM32F4 Discovery, Cortex-M4),
   reading the executed-instruction counter around each operation -> `results/node_ops-O2.json`.
   `node firmware/check_node.js` checks the firmware outputs against an independent BigInt implementation (18/18 agree).
2. `network_sim.js` : signing chain over lossy multi-hop IEEE 802.15.4 with node times = instructions x CPI / f
   -> `results/network_sim.txt`, `results/network_sim.json`.
3. `tools/` : downloaded toolchain, emulator and mbed TLS source (not part of the supplementary material).

Renode counts instructions; it does not model the Cortex-M4 pipeline, so times are estimates (CPI 1.0 and 1.5 assumed).
