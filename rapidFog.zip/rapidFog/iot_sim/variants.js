'use strict';
/*
 * Node-cost reduction options for RapidFog, measured on the emulated Cortex-M4 (instruction counts from Renode):
 *   - modulus size: 2048 (paper), 1536, 1024 bits (smaller moduli lower the security level: roughly 112, 96, 80 bits);
 *   - an elliptic-curve variant over P-256 (cost ESTIMATE: three generic scalar multiplications plus a try-and-increment
 *     hash-to-curve per node; the variant is not designed or proved in the paper, and it needs messages encoded as points).
 * Chain latency uses the radio model of network_sim.js (loss 5%). Run: node variants.js > results/variants.txt
 */
const fs = require('fs'), path = require('path');
const R = (f) => JSON.parse(fs.readFileSync(path.join(__dirname, 'results', f), 'utf8')).instructions;
const o2048 = R('node_ops-O2.json'), o1536 = R('node_ops-O2_b1536.json'), o1024 = R('node_ops-O2_b1024.json');
const lap = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'code', 'results.json'), 'utf8')).cost;
const FV_MS = lap.tFV / 1000;

const NET = { payload: 100, air: 133 * 8 / 250, ack: 0.352 + 0.192, ackWait: 0.864, csma: 2.24, retries: 3 };
const mulberry32 = (a) => () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const frames = (b) => Math.ceil(b / NET.payload);
function send(rng, p, bytes) { let t = 0; for (let k = 0; k < frames(bytes); k++) { let ok = false; for (let a = 0; a <= NET.retries && !ok; a++) { t += rng() * NET.csma + NET.air; if (rng() >= p) { t += NET.ack; ok = true; } else t += NET.ackWait; } if (!ok) return null; } return t; }
function chain(rng, n, p, tEnc, tHop, bytes, tFog) { let t = tEnc; for (let i = 0; i < n; i++) { const d = send(rng, p, bytes); if (d === null) return null; t += d; if (i < n - 1) t += tHop; } return t + tFog; }

const ecAS = 3 * o2048.EC_MUL + o2048.EC_H2C;
const variants = [
  { name: 'modulus 2048 bits (paper)', as: o2048.AS, enc: o2048.ENC, bytes: 3 * 256 + 10, level: '~112 bit' },
  { name: 'modulus 1536 bits', as: o1536.AS, enc: o1536.ENC, bytes: 3 * 192 + 10, level: '~96 bit' },
  { name: 'modulus 1024 bits', as: o1024.AS, enc: o1024.ENC, bytes: 3 * 128 + 10, level: '~80 bit' },
  { name: 'P-256 variant (estimate)', as: ecAS, enc: ecAS, bytes: 3 * 33 + 10, level: '~128 bit' },
];
const DEVICES = [{ name: 'STM32F4 @168 MHz', f: 168 }, { name: 'nRF52840 @64 MHz', f: 64 }];
const CPI = 1.5, P = 0.05, TR = 3000, N = [10, 20, 50];
const med = (a) => a.sort((x, y) => x - y)[Math.floor(a.length / 2)];

console.log('Node-cost options (instructions per AS hop; CPI 1.5 assumed; loss 5%)');
console.log('MPI exponentiations use mbed TLS portable C (window 4); the EC estimate uses mbed TLS generic P-256 multiplication, also portable C.\n');
for (const dev of DEVICES) {
  console.log(`== ${dev.name} ==`);
  console.log('variant                        security  AS instr  AS ms   tuple B  frames |  chain median s for n = ' + N.join(', '));
  for (const v of variants) {
    const tAS = v.as * CPI / (dev.f * 1000), tEnc = v.enc * CPI / (dev.f * 1000);
    const cols = N.map((n) => { const rng = mulberry32(77 + n), l = []; for (let k = 0; k < TR; k++) { const r = chain(rng, n, P, tEnc, tAS, v.bytes, FV_MS); if (r !== null) l.push(r); } return (med(l) / 1000).toFixed(1); });
    console.log(`${v.name.padEnd(30)} ${v.level.padEnd(9)} ${(v.as / 1e6).toFixed(1).padStart(6)}M ${tAS.toFixed(0).padStart(6)}  ${String(v.bytes).padStart(6)}  ${String(frames(v.bytes)).padStart(5)}  |  ${cols.join(', ')}`);
  }
  console.log('');
}
console.log(`Reference: ECDSA P-256 signature on the node ${(o2048.ECDSA_SIGN / 1e6).toFixed(1)}M instructions; generic P-256 scalar multiplication ${(o2048.EC_MUL / 1e6).toFixed(1)}M.`);
