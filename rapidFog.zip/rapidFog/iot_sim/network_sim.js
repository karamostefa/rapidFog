'use strict';
/*
 * Discrete-event simulation of one RapidFog signing chain over a lossy multi-hop IEEE 802.15.4 network, with node
 * computation times derived from the instruction counts of the Cortex-M4 firmware (results/node_ops-O2.json, from Renode).
 *
 *   node N1: Enc_Sig  ->  frames(tuple) -> node N2: AS -> ... -> node Nn: AS -> frames(tuple) -> fog node F: FV
 *
 * Radio model (same as the e2e simulation of the e-Health paper): 250 kbit/s, 133-byte PHY frames carrying up to 100 bytes
 * of payload, unslotted CSMA-CA backoff (uniform in [0, 2.24] ms), link-layer ACK, per-attempt frame loss p, up to
 * 3 retransmissions; a frame that fails after all retries aborts the chain (the cluster has to start again).
 * One hop between consecutive nodes; the last node reaches the fog node over one hop; links do not contend with each other
 * (a chain sends one message at a time).
 * Execution time = instructions x CPI / f. Renode counts instructions but does not model the pipeline, so the CPI is an
 * explicit assumption: 1.0 (lower bound) and 1.5 (a typical figure for load/store-heavy big-number code on a Cortex-M4).
 * The fog node is not constrained: FV uses the laptop measurement of the paper (1.01 ms).
 * Baseline: an aggregate MAC chain (each node verifies and extends an HMAC-SHA256 aggregate, 32-byte payload); its per-node
 * cost is taken as 8 SHA-256 compressions (two HMACs, 4 compressions each) at the measured instruction count of one compression.
 * Run: node network_sim.js > results/network_sim.txt
 */
const fs = require('fs'), path = require('path');
const ops = JSON.parse(fs.readFileSync(path.join(__dirname, 'results', 'node_ops-O2.json'), 'utf8')).instructions;
const lap = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'code', 'results.json'), 'utf8')).cost;
const FV_FOG_MS = lap.tFV / 1000;

const NET = { payload: 100, air: 133 * 8 / 250, ack: 0.352 + 0.192, ackWait: 0.864, csma: 2.24, retries: 3 };
const TUPLE = 768 + 10;                        // (a, b, e) plus epoch and counter
const DEVICES = [{ name: 'STM32F4-class Cortex-M4 @168 MHz', f: 168 }, { name: 'nRF52840-class Cortex-M4F @64 MHz', f: 64 }];
const CPIS = [1.0, 1.5];
const SIZES = [2, 5, 10, 20, 50, 100];
const LOSS = [0, 0.05, 0.10, 0.20];
const TRIALS = 4000;

function mulberry32(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const cpuMs = (instr, dev, cpi) => instr * cpi / (dev.f * 1000);
const frames = (bytes) => Math.ceil(bytes / NET.payload);

function sendMessage(rng, p, bytes) {          // time to deliver a message over one hop, or null if a frame is lost
  let t = 0;
  for (let k = 0; k < frames(bytes); k++) {
    let ok = false;
    for (let a = 0; a <= NET.retries && !ok; a++) { t += rng() * NET.csma + NET.air; if (rng() >= p) { t += NET.ack; ok = true; } else t += NET.ackWait; }
    if (!ok) return null;
  }
  return t;
}
function chain(rng, n, p, tEnc, tHop, bytes, tFog) {
  let t = tEnc, comp = tEnc;
  for (let i = 0; i < n; i++) {
    const d = sendMessage(rng, p, bytes); if (d === null) return null; t += d;
    if (i < n - 1) { t += tHop; comp += tHop; }
  }
  return { total: t + tFog, comp: comp + tFog };
}
const pct = (a, q) => a[Math.min(a.length - 1, Math.floor(q * a.length))];
const out = { meta: { ops, FV_FOG_MS, NET, TRIALS }, rows: [] };
const log = (s) => console.log(s);

log('Node operations (Renode, Cortex-M4, mbed TLS bignum, 2048-bit modulus), instructions:');
log('  ' + Object.entries(ops).map(([k, v]) => `${k} ${(v / 1e6).toFixed(2)}M`).join(' | '));
log(`Frames per tuple: ${frames(TUPLE)}; fog FV: ${FV_FOG_MS.toFixed(2)} ms\n`);
log('Single-operation time on the node (ms):');
for (const dev of DEVICES) for (const cpi of CPIS)
  log(`  ${dev.name}, CPI ${cpi}: AS ${cpuMs(ops.AS, dev, cpi).toFixed(0)} | ENC ${cpuMs(ops.ENC, dev, cpi).toFixed(0)} | one H_G ${cpuMs(ops.HG, dev, cpi).toFixed(1)} | one SHA-256 block ${cpuMs(ops.SHA64, dev, cpi).toFixed(3)} | ECDSA P-256 sign ${cpuMs(ops.ECDSA_SIGN, dev, cpi).toFixed(1)} verify ${cpuMs(ops.ECDSA_VERIFY, dev, cpi).toFixed(1)}`);
log(`  node-side cost ratio AS / ECDSA sign = ${(ops.AS / ops.ECDSA_SIGN).toFixed(1)}x; first node ENC / ECDSA sign = ${(ops.ENC / ops.ECDSA_SIGN).toFixed(1)}x
`);

for (const dev of DEVICES) for (const cpi of CPIS) {
  const tEnc = cpuMs(ops.ENC, dev, cpi), tAS = cpuMs(ops.AS, dev, cpi);
  const tAm = cpuMs(8 * ops.SHA64, dev, cpi);
  log(`== ${dev.name}, CPI ${cpi} ==`);
  log('   n   loss   RapidFog median [p95] s  (compute share)  success   | AggMAC chain median s  success');
  for (const n of SIZES) for (const p of LOSS) {
    const rng = mulberry32(1000 + n * 7 + Math.round(p * 100));
    const lat = [], comps = []; let fail = 0; const latA = []; let failA = 0;
    for (let k = 0; k < TRIALS; k++) {
      const r = chain(rng, n, p, tEnc, tAS, TUPLE, FV_FOG_MS); if (r) { lat.push(r.total); comps.push(r.comp / r.total); } else fail++;
      const a = chain(rng, n, p, tAm, tAm, 32 + 10, 0.05); if (a) latA.push(a.total); else failA++;
    }
    lat.sort((x, y) => x - y); latA.sort((x, y) => x - y);
    const row = { device: dev.name, f: dev.f, cpi, n, p, median_s: lat.length ? pct(lat, 0.5) / 1000 : null, p95_s: lat.length ? pct(lat, 0.95) / 1000 : null,
      compute_share: comps.length ? comps.reduce((x, y) => x + y, 0) / comps.length : null, success: lat.length / TRIALS,
      amac_median_s: latA.length ? pct(latA, 0.5) / 1000 : null, amac_success: latA.length / TRIALS };
    out.rows.push(row);
    log(`${String(n).padStart(4)}  ${(p * 100).toFixed(0).padStart(3)}%   ${row.median_s === null ? '    -' : row.median_s.toFixed(2).padStart(7)} [${row.p95_s === null ? '-' : row.p95_s.toFixed(2)}]  (${row.compute_share === null ? '-' : (100 * row.compute_share).toFixed(0) + '%'})   ${(100 * row.success).toFixed(1)}%   |  ${row.amac_median_s === null ? '-' : row.amac_median_s.toFixed(2)}  ${(100 * row.amac_success).toFixed(1)}%`);
  }
  log('');
}
fs.writeFileSync(path.join(__dirname, 'results', 'network_sim.json'), JSON.stringify(out, null, 1));
