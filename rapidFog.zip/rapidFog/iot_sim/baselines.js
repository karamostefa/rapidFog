'use strict';
/*
 * Per-node cost of RapidFog against the baselines of the paper, on the emulated Cortex-M4 (Renode instruction counts).
 * Measured on the emulator: RapidFog AS and ENC (2048-bit modulus), ECDSA P-256 signature (per-node signature baseline),
 * MuSig2 signer on P-256 (2 fixed-base multiplications, 3 hashes, partial signature).
 * Estimated from the measured SHA-256 compression: Group MAC = 4 compressions (one HMAC), aggregate MAC = 8 (verify + extend).
 * NOT measured: BLS multi-signatures (no pairing library in the toolchain; the signer would need a hash-to-curve and one
 * scalar multiplication on a 381-bit curve, plausibly a few times a P-256 multiplication). Verifier costs are the laptop
 * figures of the paper, not emulated. CPI 1.5 assumed. Run: node baselines.js > results/baselines.txt
 */
const fs = require('fs'), path = require('path');
const o = JSON.parse(fs.readFileSync(path.join(__dirname, 'results', 'node_ops-O2.json'), 'utf8')).instructions;
const DEV = [{ n: 'STM32F4 @168 MHz', f: 168 }, { n: 'nRF52840 @64 MHz', f: 64 }];
const CPI = 1.5;
const rows = [
  { s: 'Per-node ECDSA P-256 (n signatures)', ins: o.ECDSA_SIGN, bytes: 64, rounds: 1, ver: 'n checks (72 us each, paper)', state: 'n public keys' },
  { s: 'MuSig2 on P-256 (multi-signature)', ins: o.MUSIG2_SIGNER, bytes: 2 * 33 + 32, rounds: 2, ver: '1 Schnorr check (112 us, paper)', state: '1 aggregate key' },
  { s: 'Group MAC', ins: 4 * o.SHA64, bytes: 32, rounds: 1, ver: '1 MAC', state: '1 shared key' },
  { s: 'Aggregate MAC (chain)', ins: 8 * o.SHA64, bytes: 32, rounds: 1, ver: 'n MACs', state: 'n keys and ids' },
  { s: 'RapidFog, relay node (AS), 2048-bit', ins: o.AS, bytes: 3 * 256 + 10, rounds: 1, ver: '3 short exp. (1.01 ms, paper)', state: '3 values' },
  { s: 'RapidFog, first node (Enc_Sig), 2048-bit', ins: o.ENC, bytes: 3 * 256 + 10, rounds: 1, ver: '(same tuple)', state: '' },
];
console.log(`Per-node compute on the emulated Cortex-M4 (CPI ${CPI}); bytes = data a node sends per report; rounds = communication rounds\n`);
console.log('scheme'.padEnd(42) + 'instr(M)'.padStart(9) + DEV.map((d) => d.n.padStart(20)).join('') + '  bytes  rounds  verifier / state');
for (const r of rows)
  console.log(r.s.padEnd(42) + (r.ins / 1e6).toFixed(2).padStart(9) + DEV.map((d) => ((r.ins * CPI / (d.f * 1000)).toFixed(1) + ' ms').padStart(20)).join('') + String(r.bytes).padStart(7) + String(r.rounds).padStart(7) + '   ' + r.ver + (r.state ? '; ' + r.state : ''));
console.log(`\nRapidFog relay vs MuSig2 signer: ${(o.AS / o.MUSIG2_SIGNER).toFixed(1)}x; vs per-node ECDSA: ${(o.AS / o.ECDSA_SIGN).toFixed(1)}x; vs aggregate MAC: ${(o.AS / (8 * o.SHA64)).toFixed(0)}x`);
