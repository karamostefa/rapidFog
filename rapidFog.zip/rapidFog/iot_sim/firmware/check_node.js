'use strict';
// Cross-check of the firmware outputs (../results/node_uart.txt) against an independent BigInt implementation.
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const P = BigInt('0x' + fs.readFileSync(path.join(__dirname, '..', '..', 'code', 'safeprime.txt'), 'utf8').trim());
const sha = (...b) => { const h = crypto.createHash('sha256'); for (const x of b) h.update(x); return h.digest(); };
const toBig = (buf) => BigInt('0x' + (buf.length ? Buffer.from(buf).toString('hex') : '0'));
const toBytes = (x, n) => Buffer.from(x.toString(16).padStart(2 * n, '0'), 'hex');
function prng(label, bits) {
  const nbytes = Math.ceil(bits / 8), parts = [];
  for (let ctr = 0; ctr * 32 < nbytes; ctr++) parts.push(sha(Buffer.from(label), Buffer.from([ctr])));
  let x = toBig(Buffer.concat(parts).subarray(0, nbytes));
  if (bits % 8) x >>= BigInt(8 * nbytes - bits);
  return x | (1n << BigInt(bits - 1));
}
function mpow(b, e, m) { let r = 1n; b %= m; while (e > 0n) { if (e & 1n) r = r * b % m; e >>= 1n; b = b * b % m; } return r; }
let lastU2 = 0n;
function HG(m) {
  const mb = toBytes(m, 256), parts = [];
  for (let ctr = 0; ctr < 9; ctr++) parts.push(sha(Buffer.from('HG'), mb, Buffer.from([ctr])));
  const u = toBig(Buffer.concat(parts)) % P; lastU2 = u * u; return lastU2 % P;
}
const M = prng('M', 2040), E = prng('E', 2040), A = prng('A', 2040), B = prng('B', 2040);
const C1 = prng('c1', 256), C2 = prng('c2', 256), T = prng('t', 256), S1 = prng('S1', 262), S2 = prng('S2', 262), Ss = prng('s', 2040);
const tail = (x) => toBytes(x, 512).subarray(504).toString('hex');
const exp = [];
let R1 = 0n, R2 = 0n, R3 = 0n;
R1 = mpow(M, C1, P); exp.push([R1, R2, R3]);                                   // EXP256
R1 = HG(M); R3 = lastU2; exp.push([R1, R2, R3]);                                // HG
{ const mh = mpow(E, T, P), h = HG(mh), t1 = mpow(mh, C1, P), t2 = mpow(h, C2, P);   // AS
  R1 = A * t1 % P; R3 = B * t2; R2 = R3 % P; exp.push([R1, R2, R3]); }
{ R1 = mpow(M, C1, P); const h = HG(M); R2 = mpow(h, C2, P); R3 = mpow(M, Ss, P); exp.push([R1, R2, R3]); }   // ENC
{ const mh = mpow(E, T, P); R1 = mpow(mh, S1, P); const h = HG(mh); R3 = lastU2; R2 = mpow(h, S2, P); exp.push([R1, R2, R3]); }   // FV
exp.push(exp[exp.length - 1]);                                                  // SHA64 leaves registers unchanged
const txt = fs.readFileSync(path.join(__dirname, '..', 'results', 'node_uart.txt'), 'utf8').split(/\r?\n/);
const got = []; let cur = null;
for (const l of txt) { const m = l.match(/^done (\w+)/); if (m) { cur = []; got.push(cur); } const t = l.match(/^R([123]) ([0-9a-f]{16})/); if (t && cur) cur[t[1] - 1] = t[2]; }
let ok = 0, n = 0; const names = ['EXP256', 'HG', 'AS', 'ENC', 'FV', 'SHA64'];
exp.forEach((e, i) => { const a = [tail(e[0]), tail(e[1]), tail(e[2])]; for (let k = 0; k < 3; k++) { n++; if (a[k] === got[i][k]) ok++; else console.log('MISMATCH', names[i], 'R' + (k + 1), a[k], got[i][k]); } });
console.log(`firmware vs BigInt: ${ok}/${n} register tails agree`);
