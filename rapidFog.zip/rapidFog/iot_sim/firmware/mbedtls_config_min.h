/* Minimal mbed TLS configuration: big-number arithmetic and SHA-256 only */
#ifndef MBEDTLS_CONFIG_MIN_H
#define MBEDTLS_CONFIG_MIN_H

#define MBEDTLS_HAVE_ASM
#define MBEDTLS_NO_PLATFORM_ENTROPY
#define MBEDTLS_BIGNUM_C
#define MBEDTLS_SHA256_C
#define MBEDTLS_PLATFORM_C
#define MBEDTLS_ECP_C
#define MBEDTLS_ECDSA_C
#define MBEDTLS_ASN1_PARSE_C
#define MBEDTLS_ASN1_WRITE_C
#define MBEDTLS_ECP_DP_SECP256R1_ENABLED
#define MBEDTLS_ECP_NIST_OPTIM
#define MBEDTLS_MPI_WINDOW_SIZE       4
#define MBEDTLS_MPI_MAX_SIZE          512

#endif
