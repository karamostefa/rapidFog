/*
 * RapidFog node workload on a Cortex-M4 (instruction-level emulation in Renode).
 * Operations follow Section "Phase III/IV" of the paper:
 *   ENC  : first node, a = M^c1, b = H_G(M)^c2, e = M^s       (s full size)
 *   AS   : every further node, Mh = e^t, h = H_G(Mh), a *= Mh^c1, b *= h^c2
 *   FV   : fog node, Mh = e^t, check Mh^S1 = a and H_G(Mh)^S2 = b
 *   HG   : hash into the group, (SHA-256 counter mode to |p|+128 bits) mod p, squared
 *   SHA64: one SHA-256 compression of a 64-byte block (unit cost of the handshake MACs)
 * Big numbers: mbed TLS mbedtls_mpi_exp_mod (constant-time table lookups, window 4), the code an IoT stack would use.
 * mark_begin()/mark_end() are empty functions; Renode hooks them to read the executed-instruction counter.
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "mbedtls/bignum.h"
#include "mbedtls/sha256.h"
#include "mbedtls/ecdsa.h"

#ifndef PRIME_HEADER
#define PRIME_HEADER "prime2048.h"
#endif
#include PRIME_HEADER

volatile uint32_t g_mark;
__attribute__((noinline)) void mark_begin(uint32_t id) { g_mark = id; __asm volatile("" ::: "memory"); }
__attribute__((noinline)) void mark_end(uint32_t id)   { g_mark = id; __asm volatile("" ::: "memory"); }

static mbedtls_mpi P, RR, M, E, Aa, Bb, C1, C2, T, S1, S2, Sfull, R1, R2, R3;

#define CHK(x) do { if ((x) != 0) { printf("FAIL line %d\n", __LINE__); for (;;) {} } } while (0)

/* deterministic pseudo-random big numbers: SHA-256 in counter mode */
static void prng_fill(mbedtls_mpi *x, const char *label, int bits)
{
    uint8_t buf[320], blk[32];  /* up to 2560 bits */
    int nbytes = (bits + 7) / 8;
    for (int ctr = 0; ctr * 32 < nbytes; ctr++) {
        mbedtls_sha256_context c; mbedtls_sha256_init(&c);
        mbedtls_sha256_starts(&c, 0);
        mbedtls_sha256_update(&c, (const uint8_t *)label, strlen(label));
        uint8_t k = (uint8_t)ctr; mbedtls_sha256_update(&c, &k, 1);
        mbedtls_sha256_finish(&c, blk); mbedtls_sha256_free(&c);
        memcpy(buf + ctr * 32, blk, 32);
    }
    CHK(mbedtls_mpi_read_binary(x, buf, nbytes));
    if (bits % 8) CHK(mbedtls_mpi_shift_r(x, 8 * nbytes - bits));
    CHK(mbedtls_mpi_set_bit(x, bits - 1, 1));
}

/* H_G(m) = (H_{|p|+128}(m) mod p)^2 mod p */
static void HG(mbedtls_mpi *out, const mbedtls_mpi *m)
{
    uint8_t mb[MODBITS / 8], buf[((MODBITS + 128 + 255) / 256) * 32], blk[32];
    CHK(mbedtls_mpi_write_binary(m, mb, sizeof mb));
    for (int ctr = 0; ctr < (MODBITS + 128 + 255) / 256; ctr++) {
        mbedtls_sha256_context c; mbedtls_sha256_init(&c);
        mbedtls_sha256_starts(&c, 0);
        uint8_t k = (uint8_t)ctr;
        mbedtls_sha256_update(&c, (const uint8_t *)"HG", 2);
        mbedtls_sha256_update(&c, mb, sizeof mb);
        mbedtls_sha256_update(&c, &k, 1);
        mbedtls_sha256_finish(&c, blk); mbedtls_sha256_free(&c);
        memcpy(buf + ctr * 32, blk, 32);
    }
    CHK(mbedtls_mpi_read_binary(&R3, buf, sizeof buf));
    CHK(mbedtls_mpi_mod_mpi(&R3, &R3, &P));
    CHK(mbedtls_mpi_mul_mpi(&R3, &R3, &R3));
    CHK(mbedtls_mpi_mod_mpi(out, &R3, &P));
}

static void powm(mbedtls_mpi *r, const mbedtls_mpi *b, const mbedtls_mpi *e) { CHK(mbedtls_mpi_exp_mod(r, b, e, &P, &RR)); }
static void mulm(mbedtls_mpi *r, const mbedtls_mpi *x, const mbedtls_mpi *y)
{ CHK(mbedtls_mpi_mul_mpi(&R3, x, y)); CHK(mbedtls_mpi_mod_mpi(r, &R3, &P)); }

static void op_enc(void) { mbedtls_mpi h; mbedtls_mpi_init(&h);
    powm(&R1, &M, &C1); HG(&h, &M); powm(&R2, &h, &C2); powm(&R3, &M, &Sfull); (void)0; mbedtls_mpi_free(&h); }
static void op_as(void)  { mbedtls_mpi mh, h, t1, t2; mbedtls_mpi_init(&mh); mbedtls_mpi_init(&h); mbedtls_mpi_init(&t1); mbedtls_mpi_init(&t2);
    powm(&mh, &E, &T); HG(&h, &mh); powm(&t1, &mh, &C1); powm(&t2, &h, &C2);
    mulm(&R1, &Aa, &t1); mulm(&R2, &Bb, &t2);
    mbedtls_mpi_free(&mh); mbedtls_mpi_free(&h); mbedtls_mpi_free(&t1); mbedtls_mpi_free(&t2); }
static void op_fv(void)  { mbedtls_mpi mh, h, t1, t2; mbedtls_mpi_init(&mh); mbedtls_mpi_init(&h); mbedtls_mpi_init(&t1); mbedtls_mpi_init(&t2);
    powm(&mh, &E, &T); powm(&R1, &mh, &S1); HG(&h, &mh); powm(&R2, &h, &S2);
    mbedtls_mpi_free(&mh); mbedtls_mpi_free(&h); mbedtls_mpi_free(&t1); mbedtls_mpi_free(&t2); }
static void op_hg(void)  { HG(&R1, &M); }
static void op_exp256(void) { powm(&R1, &M, &C1); }
static void show_tail(const char *tag, const mbedtls_mpi *x)
{
    uint8_t b[512]; CHK(mbedtls_mpi_write_binary(x, b, sizeof b));
    printf("%s ", tag); for (int i = 504; i < 512; i++) printf("%02x", b[i]); printf("\n");
}
static void op_sha64(void)   { uint8_t in[64] = {0}, out[32]; mbedtls_sha256_context c; mbedtls_sha256_init(&c);
    mbedtls_sha256_starts(&c, 0); mbedtls_sha256_update(&c, in, 64); mbedtls_sha256_finish(&c, out); mbedtls_sha256_free(&c); }


/* ---- per-signer baseline: ECDSA P-256 (the alternative the paper compares with) ---- */
static mbedtls_ecdsa_context ecd;
static mbedtls_mpi sr, ss;
static uint8_t hash32[32];
static uint32_t rng_ctr;
static int det_rng(void *ctx, unsigned char *out, size_t n)
{
    (void)ctx; uint8_t blk[32];
    for (size_t off = 0; off < n; off += 32) {
        mbedtls_sha256_context c; mbedtls_sha256_init(&c); mbedtls_sha256_starts(&c, 0);
        mbedtls_sha256_update(&c, (const uint8_t *)&rng_ctr, 4); rng_ctr++;
        mbedtls_sha256_finish(&c, blk); mbedtls_sha256_free(&c);
        size_t k = n - off < 32 ? n - off : 32; memcpy(out + off, blk, k);
    }
    return 0;
}
static void op_ecdsa_sign(void)   { CHK(mbedtls_ecdsa_sign(&ecd.MBEDTLS_PRIVATE(grp), &sr, &ss, &ecd.MBEDTLS_PRIVATE(d), hash32, 32, det_rng, 0)); }
static void op_ecdsa_verify(void) { CHK(mbedtls_ecdsa_verify(&ecd.MBEDTLS_PRIVATE(grp), hash32, 32, &ecd.MBEDTLS_PRIVATE(Q), &sr, &ss)); }

/* ---- elliptic-curve variant cost: one generic P-256 scalar multiplication, and hash-to-curve by try-and-increment (2 square roots on average) ---- */
static mbedtls_ecp_point Rpt;
static mbedtls_mpi Ksc, Sqe, Xs, Ys;
static void op_ec_mul(void) { CHK(mbedtls_ecp_mul(&ecd.MBEDTLS_PRIVATE(grp), &Rpt, &Ksc, &ecd.MBEDTLS_PRIVATE(Q), det_rng, 0)); }
static void op_ec_h2c(void) { for (int i = 0; i < 2; i++) CHK(mbedtls_mpi_exp_mod(&Ys, &Xs, &Sqe, &ecd.MBEDTLS_PRIVATE(grp).P, NULL)); }

/* ---- MuSig2 signer (2 nonces, key-aggregation and nonce-coefficient hashes, partial signature) on P-256, for the multi-signature baseline.
 * Per-signer work: R1 = r1*G, R2 = r2*G (fixed-base), 3 hashes for coefficients/challenge, s = r1 + b*r2 + c*a*x mod n. ---- */
static mbedtls_ecp_point R1pt, R2pt;
static mbedtls_mpi r1n, r2n, bco, cco, aco, spart, tmpn;
static void hash_to_mpi(mbedtls_mpi *out, uint32_t tag, const uint8_t *d, size_t n)
{
    uint8_t h[32]; mbedtls_sha256_context c; mbedtls_sha256_init(&c); mbedtls_sha256_starts(&c, 0);
    mbedtls_sha256_update(&c, (const uint8_t *)&tag, 4); mbedtls_sha256_update(&c, d, n); mbedtls_sha256_finish(&c, h); mbedtls_sha256_free(&c);
    CHK(mbedtls_mpi_read_binary(out, h, 32)); CHK(mbedtls_mpi_mod_mpi(out, out, &ecd.MBEDTLS_PRIVATE(grp).N));
}
static void op_ecp_mul_g(void) { CHK(mbedtls_ecp_mul(&ecd.MBEDTLS_PRIVATE(grp), &R1pt, &Ksc, &ecd.MBEDTLS_PRIVATE(grp).G, det_rng, 0)); }
static void op_musig2_signer(void)
{
    mbedtls_mpi *n = &ecd.MBEDTLS_PRIVATE(grp).N;
    uint8_t buf[96]; memset(buf, 0x33, sizeof buf);
    CHK(mbedtls_ecp_gen_privkey(&ecd.MBEDTLS_PRIVATE(grp), &r1n, det_rng, 0));
    CHK(mbedtls_ecp_gen_privkey(&ecd.MBEDTLS_PRIVATE(grp), &r2n, det_rng, 0));
    CHK(mbedtls_ecp_mul(&ecd.MBEDTLS_PRIVATE(grp), &R1pt, &r1n, &ecd.MBEDTLS_PRIVATE(grp).G, det_rng, 0));
    CHK(mbedtls_ecp_mul(&ecd.MBEDTLS_PRIVATE(grp), &R2pt, &r2n, &ecd.MBEDTLS_PRIVATE(grp).G, det_rng, 0));
    hash_to_mpi(&aco, 1, buf, 96);       /* key-aggregation coefficient a_i = H(L, X_i) */
    hash_to_mpi(&bco, 2, buf, 96);       /* nonce coefficient b = H(Q, R1, R2, m) */
    hash_to_mpi(&cco, 3, buf, 96);       /* challenge c = H(R, Q, m) */
    CHK(mbedtls_mpi_mul_mpi(&tmpn, &cco, &aco)); CHK(mbedtls_mpi_mod_mpi(&tmpn, &tmpn, n));
    CHK(mbedtls_mpi_mul_mpi(&tmpn, &tmpn, &ecd.MBEDTLS_PRIVATE(d))); CHK(mbedtls_mpi_mod_mpi(&tmpn, &tmpn, n));
    CHK(mbedtls_mpi_mul_mpi(&spart, &bco, &r2n)); CHK(mbedtls_mpi_mod_mpi(&spart, &spart, n));
    CHK(mbedtls_mpi_add_mpi(&spart, &spart, &r1n)); CHK(mbedtls_mpi_add_mpi(&spart, &spart, &tmpn)); CHK(mbedtls_mpi_mod_mpi(&spart, &spart, n));
}

int main(void)
{
    mbedtls_mpi *all[] = { &P, &RR, &M, &E, &Aa, &Bb, &C1, &C2, &T, &S1, &S2, &Sfull, &R1, &R2, &R3 };
    for (unsigned i = 0; i < sizeof all / sizeof *all; i++) mbedtls_mpi_init(all[i]);
    CHK(mbedtls_mpi_read_string(&P, 16, PHEX));
    prng_fill(&M, "M", MODBITS - 8); prng_fill(&E, "E", MODBITS - 8); prng_fill(&Aa, "A", MODBITS - 8); prng_fill(&Bb, "B", MODBITS - 8);
    prng_fill(&C1, "c1", 256); prng_fill(&C2, "c2", 256); prng_fill(&T, "t", 256);
    prng_fill(&S1, "S1", 262); prng_fill(&S2, "S2", 262); prng_fill(&Sfull, "s", MODBITS - 8);
    printf("RapidFog firmware: |p|=%u bits\n", (unsigned)mbedtls_mpi_bitlen(&P));
    mbedtls_ecdsa_init(&ecd); mbedtls_mpi_init(&sr); mbedtls_mpi_init(&ss);
    CHK(mbedtls_ecdsa_genkey(&ecd, MBEDTLS_ECP_DP_SECP256R1, det_rng, 0));
    mbedtls_ecp_point_init(&Rpt); mbedtls_mpi_init(&Ksc); mbedtls_mpi_init(&Sqe); mbedtls_mpi_init(&Xs); mbedtls_mpi_init(&Ys);
    prng_fill(&Ksc, "ksc", 255); prng_fill(&Xs, "xs", 255);
    CHK(mbedtls_mpi_add_int(&Sqe, &ecd.MBEDTLS_PRIVATE(grp).P, 1)); CHK(mbedtls_mpi_shift_r(&Sqe, 2));
    mbedtls_ecp_point_init(&R1pt); mbedtls_ecp_point_init(&R2pt);
    mbedtls_mpi_init(&r1n); mbedtls_mpi_init(&r2n); mbedtls_mpi_init(&bco); mbedtls_mpi_init(&cco); mbedtls_mpi_init(&aco); mbedtls_mpi_init(&spart); mbedtls_mpi_init(&tmpn);
    memset(hash32, 0x5a, 32); op_ecdsa_sign();      /* warm-up and a valid signature for the verify op */
    op_ecp_mul_g();                     /* warm-up: builds the fixed-base comb table */
    op_exp256();                       /* warm-up: computes and caches R^2 mod p (RR) */

    struct { const char *name; void (*fn)(void); uint32_t id; } ops[] = {
        { "EXP256", op_exp256, 1 }, { "HG", op_hg, 2 }, { "AS", op_as, 3 }, { "ENC", op_enc, 4 }, { "FV", op_fv, 5 }, { "SHA64", op_sha64, 6 }, { "ECDSA_SIGN", op_ecdsa_sign, 7 }, { "ECDSA_VERIFY", op_ecdsa_verify, 8 }, { "EC_MUL", op_ec_mul, 9 }, { "EC_H2C", op_ec_h2c, 10 }, { "ECP_MUL_G", op_ecp_mul_g, 11 }, { "MUSIG2_SIGNER", op_musig2_signer, 12 }
    };
    for (unsigned i = 0; i < sizeof ops / sizeof *ops; i++) {
        mark_begin(ops[i].id); ops[i].fn(); mark_end(ops[i].id);
        printf("done %s\n", ops[i].name);
        show_tail("R1", &R1); show_tail("R2", &R2); show_tail("R3", &R3);
    }
    printf("ALL DONE\n");
    for (;;) { }
}
