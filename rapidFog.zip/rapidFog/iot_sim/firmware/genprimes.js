'use strict';
// Safe primes of 1024 and 1536 bits for the cost sweep (performance only) and the 2048-bit prime of the paper.
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const write = (bits, hex) => fs.writeFileSync(path.join(__dirname, `prime${bits}.h`), `#define MODBITS ${bits}\n#define PHEX "${hex}"\n`);
write(2048, fs.readFileSync(path.join(__dirname, '..', '..', 'code', 'safeprime.txt'), 'utf8').trim());
for (const bits of [1024, 1536]) {
  const t0 = Date.now();
  const p = crypto.generatePrimeSync(bits, { safe: true, bigint: true });
  write(bits, p.toString(16));
  console.log(bits, 'bits safe prime', ((Date.now() - t0) / 1000).toFixed(1), 's');
}
