#!/bin/sh
# Build the RapidFog node firmware for Cortex-M4 with the downloaded xPack arm-none-eabi-gcc and mbed TLS 3.6.8
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TOOLS="$HERE/../tools"
GCC="$(ls -d "$TOOLS"/armgcc/xpack-arm-none-eabi-gcc-*)/bin/arm-none-eabi-gcc.exe"
MB="$TOOLS/mbedtls-3.6.8"
OPT="${OPT:--O2}"
PH="${PRIMEH:-prime2048.h}"
CPU="${CPU:--mcpu=cortex-m4 -mfloat-abi=soft}"
OUT="${OUT:-$HERE/rapidfog_node.elf}"
"$GCC" $CPU -mthumb $OPT -ffunction-sections -fdata-sections -Wall \
  -DMBEDTLS_CONFIG_FILE='"mbedtls_config_min.h"' -DPRIME_HEADER="\"$PH\"" -I"$HERE" -I"$MB/include" -I"$MB/library" \
  "$HERE/startup.c" "$HERE/main.c" \
  "$MB/library/bignum.c" "$MB/library/bignum_core.c" "$MB/library/constant_time.c" \
  "$MB/library/platform_util.c" "$MB/library/platform.c" "$MB/library/sha256.c" \
  "$MB/library/ecp.c" "$MB/library/ecp_curves.c" "$MB/library/ecdsa.c" "$MB/library/asn1parse.c" "$MB/library/asn1write.c" \
  "$MB/library/bignum_mod.c" "$MB/library/bignum_mod_raw.c" \
  -nostartfiles --specs=nano.specs --specs=nosys.specs -Wl,--gc-sections -Wl,-T,"$HERE/link.ld" \
  -Wl,-Map,"${OUT%.elf}.map" -o "$OUT" -lc -lgcc
"$(dirname "$GCC")/arm-none-eabi-size.exe" "$OUT"
