#include <stdint.h>
#include <stddef.h>
#include <errno.h>

extern uint32_t _estack, _sidata, _sdata, _edata, _sbss, _ebss, end;
extern int main(void);

void Default_Handler(void) { for (;;) { } }

void Reset_Handler(void)
{
    uint32_t *src = &_sidata, *dst = &_sdata;
    while (dst < &_edata) *dst++ = *src++;
    for (dst = &_sbss; dst < &_ebss; ) *dst++ = 0;
    main();
    for (;;) { }
}

__attribute__((section(".isr_vector"), used))
const void *const vector_table[16] = {
    &_estack, Reset_Handler, Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, 0, 0, 0, 0, Default_Handler, Default_Handler, 0, Default_Handler, Default_Handler
};

/* newlib retargeting: heap grows from `end` up to the stack guard, console goes to USART2 */
void *_sbrk(ptrdiff_t incr)
{
    static char *heap = 0;
    if (!heap) heap = (char *)&end;
    char *prev = heap;
    if (heap + incr > (char *)&_estack - 16384) { errno = ENOMEM; return (void *)-1; }
    heap += incr;
    return prev;
}

#define USART2_SR  (*(volatile uint32_t *)0x40004400u)
#define USART2_DR  (*(volatile uint32_t *)0x40004404u)
#define USART2_CR1 (*(volatile uint32_t *)0x4000440Cu)

int _write(int fd, const char *buf, int len)
{
    (void)fd;
    USART2_CR1 = 0x200Cu; /* UE | TE | RE */
    for (int i = 0; i < len; i++) USART2_DR = (uint32_t)buf[i];
    return len;
}
int _read(int fd, char *b, int n) { (void)fd; (void)b; (void)n; return 0; }
int _close(int fd) { (void)fd; return -1; }
int _lseek(int fd, int o, int w) { (void)fd; (void)o; (void)w; return 0; }
int _fstat(int fd, void *st) { (void)fd; (void)st; return 0; }
int _isatty(int fd) { (void)fd; return 1; }
int _getpid(void) { return 1; }
int _kill(int p, int s) { (void)p; (void)s; return -1; }
void _exit(int c) { (void)c; for (;;) { } }
