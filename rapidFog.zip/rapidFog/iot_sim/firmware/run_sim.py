"""Build the node firmware, run it in Renode (Cortex-M4, STM32F4) and extract instruction counts per operation.

usage: python run_sim.py [-O2|-Os]      (writes ../results/node_ops.json and node_uart.txt)
Renode counts executed instructions; execution time is derived afterwards under an explicit cycles-per-instruction
assumption (see network_sim.js), because Renode does not model the Cortex-M4 pipeline.
"""
import json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, '..', 'tools')
RESULTS = os.path.join(HERE, '..', 'results')
os.makedirs(RESULTS, exist_ok=True)
opt = sys.argv[1] if len(sys.argv) > 1 else '-O2'
bits = int(sys.argv[2]) if len(sys.argv) > 2 else 2048

gccdir = [d for d in os.listdir(os.path.join(TOOLS, 'armgcc')) if d.startswith('xpack-arm-none-eabi-gcc')][0]
nm = os.path.join(TOOLS, 'armgcc', gccdir, 'bin', 'arm-none-eabi-nm.exe')
size = os.path.join(TOOLS, 'armgcc', gccdir, 'bin', 'arm-none-eabi-size.exe')
renode = os.path.join(TOOLS, 'renode', 'renode_1.17.0-portable', 'renode.exe')
elf = os.path.join(HERE, 'rapidfog_node.elf')

env = dict(os.environ, OPT=opt, PRIMEH=f'prime{bits}.h')
subprocess.run(['sh', os.path.join(HERE, 'build.sh')], check=True, env=env, cwd=HERE, stdout=subprocess.DEVNULL)
sz = subprocess.run([size, elf], capture_output=True, text=True).stdout.strip().splitlines()[-1].split()
syms = subprocess.run([nm, elf], capture_output=True, text=True).stdout
addr = {m.group(2): m.group(1) for m in re.finditer(r'^([0-9a-f]{8}) T (\w+)$', syms, re.M)}

uart = os.path.join(tempfile.gettempdir(), 'rf_uart.txt').replace('\\', '/')
if os.path.exists(uart): os.remove(uart)
resc = f'''using sysbus
mach create "node"
machine LoadPlatformDescription @platforms/boards/stm32f4_discovery-kit.repl
sysbus LoadELF @rapidfog_node.elf
logLevel 3
sysbus.cpu PerformanceInMips 168
sysbus.cpu AddHook 0x{addr['mark_begin']} "print 'BEGIN', cpu.ExecutedInstructions"
sysbus.cpu AddHook 0x{addr['mark_end']} "print 'END', cpu.ExecutedInstructions"
sysbus.usart2 CreateFileBackend @{uart} true
emulation RunFor "30"
quit
'''
open(os.path.join(HERE, 'run_renode.resc'), 'w').write(resc)
out = subprocess.run([renode, '--disable-xwt', '--console', '-e', 'i @run_renode.resc'], cwd=HERE,
                     capture_output=True, text=True, timeout=1800).stdout
out = re.sub(r'\x1b\[[0-9;]*m', '', out)
counts = [int(x) for x in re.findall(r'^(?:BEGIN|END) (\d+)$', out, re.M)]
pairs = [counts[i + 1] - counts[i] for i in range(0, len(counts), 2)]
names = ['EXP256', 'HG', 'AS', 'ENC', 'FV', 'SHA64', 'ECDSA_SIGN', 'ECDSA_VERIFY', 'EC_MUL', 'EC_H2C', 'ECP_MUL_G', 'MUSIG2_SIGNER']
assert len(pairs) == len(names), (pairs, out[-500:])
text = open(uart).read()
open(os.path.join(RESULTS, 'node_uart.txt' if bits == 2048 else f'node_uart_b{bits}.txt'), 'w').write(text)
res = {'opt': opt, 'cpu': 'Cortex-M4 (Renode STM32F4)', 'modulus_bits': bits,
       'code_size': {'text': int(sz[0]), 'data': int(sz[1]), 'bss': int(sz[2])},
       'instructions': dict(zip(names, pairs))}
json.dump(res, open(os.path.join(RESULTS, (f'node_ops{opt}.json' if bits == 2048 else f'node_ops{opt}_b{bits}.json')), 'w'), indent=1)
print(json.dumps(res, indent=1))
print(text)
